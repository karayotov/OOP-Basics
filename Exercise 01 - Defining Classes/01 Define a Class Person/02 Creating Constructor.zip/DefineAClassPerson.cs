﻿class DefineAClassPerson
{
    static void Main(string[] args)
    {
        Person person = new Person();
    }
}