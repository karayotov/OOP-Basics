﻿public class Sad : Mood
{
    public Sad(int happinessPoints) : base(happinessPoints)
    {
    }
}