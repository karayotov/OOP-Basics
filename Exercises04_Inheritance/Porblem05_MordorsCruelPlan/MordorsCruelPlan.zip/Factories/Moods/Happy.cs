﻿public class Happy : Mood
{
    public Happy(int happinessPoints) : base(happinessPoints)
    {
        
    }
}
