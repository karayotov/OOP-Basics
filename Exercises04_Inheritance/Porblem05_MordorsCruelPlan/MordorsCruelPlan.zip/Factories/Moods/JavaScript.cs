﻿public class JavaScript : Mood
{
    public JavaScript(int happinessPoints) : base(happinessPoints)
    {
    }
}