﻿public abstract class Mood
{
    private int happinessPoints;

    public Mood(int happinessPoints)
    {
        this.happinessPoints = happinessPoints;
    }
}