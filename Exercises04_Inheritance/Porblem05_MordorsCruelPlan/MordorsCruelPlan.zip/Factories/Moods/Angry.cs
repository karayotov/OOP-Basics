﻿public class Angry : Mood
{
    public Angry(int happinessPoints) : base (happinessPoints)
    {

    }
}
