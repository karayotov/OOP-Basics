﻿public class Other : Food
{
    private new const int PointsOfHappines = -1;

    public Other() : base(PointsOfHappines)
    {
    }
}