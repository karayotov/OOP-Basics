﻿using System;
using System.Collections.Generic;
using System.Text;

public class Messages
{
    public static string blowedTyre = "Blown tyre";

    public static string emptyFuelTank = "Out of fuel";

    public static string crashed = "Crashed";
    
    
    //mine exceptions
    public static string missingTyreType = "Missing tyre type!";

    public static string missingDriverType = "Missing driver type!";
}