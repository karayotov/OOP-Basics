﻿public interface ICitizen
{
    string Name { get; }
    string Id { get; }
}