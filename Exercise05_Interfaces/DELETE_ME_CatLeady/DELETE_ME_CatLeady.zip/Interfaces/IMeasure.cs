﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IMeasure
{
    double Size { get; }
}
