﻿
public interface IIdentifiable : IPerson
{
    string Id { get; }
}