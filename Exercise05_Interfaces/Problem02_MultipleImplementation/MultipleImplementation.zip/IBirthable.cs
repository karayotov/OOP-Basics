﻿
public interface IBirthable : IPerson
{
    string Birthdate { get; }
}