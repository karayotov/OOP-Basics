﻿public interface ICar
{
    string Model();
    string Brake();
    string Accelerate();
    string Driver { get; }
}