﻿public interface ICitizen : IBirthable
{
    string Name { get; }
    string Id { get; }
}